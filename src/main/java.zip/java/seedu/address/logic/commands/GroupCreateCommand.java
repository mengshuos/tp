package seedu.address.logic.commands;

import static java.util.Objects.requireNonNull;

import seedu.address.logic.commands.exceptions.CommandException;
import seedu.address.model.Model;

/**
 * Creates a group by name. Uniqueness is NOT enforced in this version.
 */
public class GroupCreateCommand extends Command {

    public static final String COMMAND_WORD = "group/create";

    public static final String MESSAGE_SUCCESS = "New group created: %s";

    private final String groupName;

    public GroupCreateCommand(String groupName) {
        this.groupName = groupName;
    }

    @Override
    public CommandResult execute(Model model) throws CommandException {
        requireNonNull(model);
        // No-op against model since groups collection is not modeled; return success message only
        return new CommandResult(String.format(MESSAGE_SUCCESS, groupName));
    }
}


